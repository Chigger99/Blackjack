let firstCard = 10
let secondCard = 11
let sum = firstCard + secondCard
let hasBlackjack = false
let isAlive = true
let responseMessage = ""

if (sum < 21) {
  responseMessage = "Do you want another card"
 //console.log("Do you want another card?") 
} else if (sum === 21){
  responseMessage = "Blackjack"
  //console.log("Blackjack!")
  hasBlackjack = true
}
 else if (sum > 21){
  responseMessage = " You lose"
  //console.log("You lose. Sorry, chump.")
 isAlive = false
}

console.log(responseMessage)
//console.log(hasBlackjack)



function startGame(){
  
if (sum < 21) {
  responseMessage = "Do you want another card"
 //console.log("Do you want another card?") 
} else if (sum === 21){
  responseMessage = "Blackjack"
  //console.log("Blackjack!")
  hasBlackjack = true
}
 else if (sum > 21){
  responseMessage = " You lose"
  //console.log("You lose. Sorry, chump.")
 isAlive = false
} }