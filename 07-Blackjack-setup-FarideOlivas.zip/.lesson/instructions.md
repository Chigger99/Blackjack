# Instructions  

  1. Create a button that says START GAME. 
  2. Have this button call a startGame() function when clicked.
  3. Create the startGame() function and move all the conditional if-else logic into the function's body.
  4. Style the button with these specifications:
    1. text color: #016f32
    2. width: 150px
    3. background: goldenrod
